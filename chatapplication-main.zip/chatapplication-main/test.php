<?php

function callApi($action, $password, $railKey) {
    $url = $action === 'encrypt' ? 'http://127.0.0.1:5000/encrypt' : 'http://127.0.0.1:5000/decrypt';

    $data = [
        'password' => $action === 'encrypt' ? $password : null,
        'encrypted_password' => $action === 'decrypt' ? $password : null,
        'rail_key' => $railKey
    ];

    // Initialize a cURL session
    $ch = curl_init($url);

    // Set the options for cURL
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json'
    ]);

    // Execute the request and get the response
    $response = curl_exec($ch);

    // Close the cURL session
    curl_close($ch);

    // Decode the JSON response
    return json_decode($response, true);
}

// Example usage:
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action']; // 'encrypt' or 'decrypt'
    $password = $_POST['password']; // Password to encrypt/decrypt
    $railKey = (int)$_POST['rail_key']; // Rail fence key as an integer

    // Call the API
    $result = callApi($action, $password, $railKey);

    // Prepare the output based on the action
    if ($action === 'encrypt') {
        echo "Encrypted Password: " . $result['encrypted_password'];
    } else {
        echo "Decrypted Password: " . $result['decrypted_password'];
    }
}
?>

<!-- Example HTML form to test encryption/decryption -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encryption/Decryption</title>
</head>
<body>
    <form method="POST">
        <label for="action">Action:</label>
        <select name="action" id="action">
            <option value="encrypt">Encrypt</option>
            <option value="decrypt">Decrypt</option>
        </select>
        <br>

        <label for="password">Password:</label>
        <input type="text" name="password" id="password" required>
        <br>

        <label for="rail_key">Rail Fence Key:</label>
        <input type="number" name="rail_key" id="rail_key" required>
        <br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
