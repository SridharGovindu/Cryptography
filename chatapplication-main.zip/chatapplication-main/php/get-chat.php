<?php
session_start();
if (isset($_SESSION['unique_id'])) {
    include_once "config.php";
    $outgoing_id = mysqli_real_escape_string($conn, $_POST['outgoing_id']);
    $incoming_id = mysqli_real_escape_string($conn, $_POST['incoming_id']);
    $output = "";
    $railKey = 2; // Define your Rail Fence Key or retrieve it as needed

    // Function to call the API for decryption
    function callApi($action, $encrypted_password, $railKey) {
        $url = 'http://127.0.0.1:5000/decrypt'; // Assuming you're decrypting
        $data = [
            'encrypted_password' => $encrypted_password, // Change this line
            'rail_key' => $railKey
        ];

        // Initialize a cURL session
        $ch = curl_init($url);

        // Set the options for cURL
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);

        // Execute the request and get the response
        $response = curl_exec($ch);
        curl_close($ch);

        // Decode the JSON response
        return json_decode($response, true);
    }

    // Start time for the SQL query
    $startTime = microtime(true); // Start time

    $sql = "SELECT * FROM messages
            LEFT JOIN users ON users.unique_id = messages.outgoing_msg_id
            WHERE (outgoing_msg_id = {$outgoing_id} AND incoming_msg_id = {$incoming_id}) 
            OR (outgoing_msg_id = {$incoming_id} AND incoming_msg_id = {$outgoing_id}) 
            ORDER BY msg_id ASC";

    $query = mysqli_query($conn, $sql);
    if (mysqli_num_rows($query) > 0) {
        while ($row = mysqli_fetch_assoc($query)) {
            $encryptedMessage = $row['msg']; // Store the encrypted message for debugging
            error_log("Encrypted Message: " . $encryptedMessage); // Log the encrypted message
            
            if (!empty($encryptedMessage)) {
                // Decrypt the message by calling the API
                $decryptedMessageResponse = callApi('decrypt', $encryptedMessage, $railKey);
                
                // Assuming the API returns a JSON response with 'decrypted_password'
                if (isset($decryptedMessageResponse['decrypted_password'])) {
                    $decryptedMessage = $decryptedMessageResponse['decrypted_password'];
                } else {
                    error_log("Error decrypting message: " . json_encode($decryptedMessageResponse));
                    $decryptedMessage = "Decryption failed"; // Fallback message
                }
            } else {
                $decryptedMessage = "No message to decrypt"; // Handle empty messages
            }

            if ($row['outgoing_msg_id'] === $outgoing_id) {
                $output .= '<div class="chat outgoing">
                                <div class="details">
                                   <p>' . htmlspecialchars($decryptedMessage) . '</p>
                                </div>
                            </div>'; // then he is msg sender 
            } else {
                // he is receiver
                $output .= '<div class="chat incoming">
                             <img src="php/images/' . htmlspecialchars($row['image']) . '" alt="">
                                <div class="details">
                                        <p>' . htmlspecialchars($decryptedMessage) . '</p>
                                </div>
                            </div>';
            }
        }
        echo $output;
    }

    // End time for the SQL query
    $endTime = microtime(true); // End time
    $executionTime = ($endTime - $startTime); // Calculate execution time in milliseconds
    error_log("get-chat.php Execution Time: " . $executionTime . " ms"); // Log execution time
    echo $executionTime;
} else {
    header("Location: ../login.php");
}
?>
