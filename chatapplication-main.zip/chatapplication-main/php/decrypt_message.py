import sys
import random

def caesar_decipher(text, shift):
    result = []
    for char in text:
        if char.isalpha():
            shift_amount = shift % 26
            if char.islower():
                new_char = chr(((ord(char) - ord('a') - shift_amount) % 26) + ord('a'))
            else:
                new_char = chr(((ord(char) - ord('A') - shift_amount) % 26) + ord('A'))
            result.append(new_char)
        else:
            result.append(char)
    return ''.join(result)

def main():
    action = sys.argv[1]
    if action == "decrypt":
        encrypted_message = sys.argv[2]
        decrypted_message = caesar_decipher(encrypted_message, 3)  # Example using Caesar Cipher
        print(decrypted_message)

if __name__ == "__main__":
    main()
