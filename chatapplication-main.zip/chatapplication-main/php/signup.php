<?php
session_start();
include_once "config.php";

$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$lname = mysqli_real_escape_string($conn, $_POST['lname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

if (!empty($fname) && !empty($lname) && !empty($email) && !empty($password)) {
    // Check if the email is valid
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check if the email already exists
        $sql = mysqli_query($conn, "SELECT email FROM users WHERE email = '{$email}'");
        if (mysqli_num_rows($sql) > 0) {
            echo "$email - this email already exists!";
        } else {
            // Check if a file is uploaded
            if (isset($_FILES['image'])) { // if file is uploaded
                $img_name = $_FILES['image']['name']; // getting user uploaded img name
                $img_type = $_FILES['image']['type']; // getting user upload image type
                $tmp_name = $_FILES['image']['tmp_name']; // this temporary name is used to save file in our folder

                // Explode the image and get the last extension like jpg and png
                $img_explode = explode('.', $img_name);
                $img_ext = end($img_explode); // here we get the extension of a user uploaded img

                $extensions = ['png', 'jpeg', 'jpg']; // valid extensions for image

                if (in_array($img_ext, $extensions) === true) {
                    $time = time(); // get the current time
                    // Rename user file with current time to ensure unique name
                    $new_img_name = $time . $img_name;

                    // Move the user uploaded img to our folder
                    if (move_uploaded_file($tmp_name, "images/" . $new_img_name)) {
                        $status = "Active now"; // user's status
                        $random_id = rand(100, 20000); // creating random id for user

                        // Hash the password using md5
                        $hashed_password = md5($password);

                        // Insert all user data into the table
                        $sql2 = mysqli_query($conn, "INSERT INTO users (unique_id, fname, lname, email, password, image, status)
                                     VALUES ({$random_id}, '{$fname}', '{$lname}', '{$email}', '{$hashed_password}', '{$new_img_name}', '{$status}')");

                        if ($sql2) {
                            $sql3 = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
                            if (mysqli_num_rows($sql3) > 0) {
                                $row = mysqli_fetch_assoc($sql3);
                                $_SESSION['unique_id'] = $row['unique_id']; // use user unique_id in other PHP files
                                echo "succeeded";
                            }
                        } else {
                            echo "Something went wrong!";
                        }
                    }
                } else {
                    echo "Please upload the image with jpg, png, or jpeg extensions";
                }
            } else {
                echo "Please select an Image File!";
            }
        }
    } else {
        echo "$email is not a valid email";
    }
} else {
    echo "All input fields are required";
}
?>
