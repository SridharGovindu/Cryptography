<?php
session_start();
if (isset($_SESSION['unique_id'])) {
    include_once "config.php";
    $outgoing_id = mysqli_real_escape_string($conn, $_POST['outgoing_id']);
    $incoming_id = mysqli_real_escape_string($conn, $_POST['incoming_id']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $railKey = 2; // Define your Rail Fence Key or retrieve it as needed

    // Function to call the API for encryption
    function callApi($action, $password, $railKey) {
        $url = 'http://127.0.0.1:5000/encrypt'; // Assuming you're encrypting
        $data = [
            'password' => $password,
            'rail_key' => $railKey
        ];

        // Initialize a cURL session
        $ch = curl_init($url);

        // Set the options for cURL
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);

        // Execute the request and get the response
        $response = curl_exec($ch);
        curl_close($ch);

        // Decode the JSON response
        return json_decode($response, true);
    }

    // Start time for the SQL insert operation
    $startTime = microtime(true); // Start time
    
    if (!empty($message)) {
        // Encrypt the message by calling the API
        $encryptedMessageResponse = callApi('encrypt', $message, $railKey);
        
        // Assuming the API returns a JSON response with 'encrypted_password'
        if (isset($encryptedMessageResponse['encrypted_password'])) {
            $encryptedMessage = $encryptedMessageResponse['encrypted_password'];

            // Insert the encrypted message into the database
            $sql = mysqli_query($conn, "INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg)
                                         VALUES({$incoming_id}, {$outgoing_id}, '{$encryptedMessage}')") or die();
        } else {
            error_log("Error encrypting message: " . json_encode($encryptedMessageResponse));
        }
    }

    // End time for the SQL insert operation
    $endTime = microtime(true); // End time
    $executionTime = ($endTime - $startTime); // Calculate execution time in milliseconds
    error_log("insert-chat.php Execution Time: " . $executionTime . " ms"); // Log execution time
} else {
    header("Location: ../login.php");
}
?>
