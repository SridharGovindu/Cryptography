<?php
session_start();
include_once "config.php";

$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

if (!empty($email) && !empty($password)) {
    // Hash the input password using md5
    $hashed_password = md5($password);

    // Check if entered email and hashed password match any row in the database
    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}' AND password = '{$hashed_password}'");
    if (mysqli_num_rows($sql) > 0) {
        $row = mysqli_fetch_assoc($sql);
        $status = "Active now";

        // Updating user status to active now if user login successfully
        $sql2 = mysqli_query($conn, "UPDATE users SET status = '{$status}' WHERE unique_id = {$row['unique_id']}");
        if ($sql2) {
            $_SESSION['unique_id'] = $row['unique_id']; // using this session we use user unique_id in other PHP files
            echo "success";
        }
    } else {
        echo "Email or Password is incorrect";
    }
} else {
    echo "All input fields are required";
}
?>
