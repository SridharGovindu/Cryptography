import sys

import random

# Caesar Cipher Shift
SHIFT = 3

# Homophonic Substitution Dictionary with Unique Fruits and Emojis
homophonic_dict = {
    'a': ['🍎', '🍏', '🍒'],
    'b': ['🍌', '🍇', '😘'],
    'c': ['😶', '😈', '🍋'],
    'd': ['🙃', '🍑', '🍓'],
    'e': ['🍅', '🍆', '🥑'],
    'f': ['🥦', '🥕', '🥒'],
    'g': ['🥬', '🥭', '🥥'],
    'h': ['🥝', '🥜', '🍠'],
    'i': ['🍤', '🍧', '🍨'],
    'j': ['🍩', '🍪', '🎂'],
    'k': ['🍰', '😏', '🍫'],
    'l': ['🍬', '🍭', '🍮'],
    'm': ['🍯', '🥧', '🍳'],
    'n': ['🍗', '🍖', '🍔'],
    'o': ['🍟', '🍕', '🍣'],
    'p': ['🍤', '🍱', '🍚'],
    'q': ['🍙', '🍘', '🍢'],
    'r': ['🍡', '🤗', '🍨'],
    's': ['🍻', '🍺', '🥂'],
    't': ['🍷', '🍹', '🍸'],
    'u': ['🍾', '🍶', '🍼'],
    'v': ['🥄', '🍴', '🍽'],
    'w': ['🥢', '🤷', '🙂'],
    'x': ['🎃', '🎄', '☕'],
    'y': ['🍈', '🍉', '🍊'],
    'z': ['🍋', '🍌', '🍍']
}

# Reverse homophonic dictionary for decryption
reverse_homophonic_dict = {v: k for k, values in homophonic_dict.items() for v in values}

# Napoleon Cipher for Numbers (replacing each digit with an alphabetic character)
napoleon_dict = {
    '0': 'a', '1': 'b', '2': 'c', '3': 'd', '4': 'e',
    '5': 'f', '6': 'g', '7': 'h', '8': 'i', '9': 'j'
}

# Reverse Napoleon dictionary for decryption
reverse_napoleon_dict = {v: k for k, v in napoleon_dict.items()}

special_to_alpha = {
    '@': '\u2603',  # Snowman ☃
    '#': '\u2605',  # Star ★
    '$': '\u2665',  # Heart ♥
    '%': '\u266B',  # Music Note ♫
    '^': '\u262F',  # Yin Yang ☯
    '&': '\u2693',  # Anchor ⚓
    '*': '\u2359',  # Apl Functional Symbol Circle Star ⍉
    '(': '\u269B',  # Atom Symbol ⚛
    ')': '\u263D',  # Crescent Moon ☽
    '!': '\u2702'   # Scissors ✂
}

# Reverse mapping for decryption
reverse_special_to_alpha = {v: k for k, v in special_to_alpha.items()}

def replace_special_characters(text):
    return ''.join(special_to_alpha[char] if char in special_to_alpha else char for char in text)

def reverse_replace_special_characters(text):
    return ''.join(reverse_special_to_alpha[char] if char in reverse_special_to_alpha else char for char in text)

def caesar_cipher(text, shift):
    result = []
    for char in text:
        if char.isalpha():
            shift_amount = shift % 26
            if char.islower():
                # Apply shift to lowercase characters
                new_char = chr(((ord(char) - ord('a') + shift_amount) % 26) + ord('a'))
            else:
                # Apply shift to uppercase characters
                new_char = chr(((ord(char) - ord('A') + shift_amount) % 26) + ord('A'))
            result.append(new_char)
        else:
            result.append(char)
    return ''.join(result)

def caesar_decipher(text, shift):
    result = []
    for char in text:
        if char.isalpha():
            shift_amount = shift % 26
            if char.islower():
                # Apply reverse shift to lowercase characters
                new_char = chr(((ord(char) - ord('a') - shift_amount) % 26) + ord('a'))
            else:
                # Apply reverse shift to uppercase characters
                new_char = chr(((ord(char) - ord('A') - shift_amount) % 26) + ord('A'))
            result.append(new_char)
        else:
            result.append(char)
    return ''.join(result)

def homophonic_substitution(text):
    result = []
    used_symbols = set()
    for char in text:
        if char in homophonic_dict:
            options = [symbol for symbol in homophonic_dict[char] if symbol not in used_symbols]
            if options:
                symbol = random.choice(options)
                used_symbols.add(symbol)
                result.append(symbol)
            else:
                raise ValueError("Ran out of unique symbols for homophonic substitution.")
        else:
            result.append(char)
    return ''.join(result)

def homophonic_desubstitution(text):
    result = []
    for char in text:
        if char in reverse_homophonic_dict:
            result.append(reverse_homophonic_dict[char])
        else:
            result.append(char)
    return ''.join(result)

def napoleon_cipher(text):
    return ''.join(napoleon_dict[char] if char in napoleon_dict else char for char in text)

def napoleon_decipher(text):
    return ''.join(reverse_napoleon_dict[char] if char in reverse_napoleon_dict else char for char in text)

# Rail Fence Cipher
def rail_fence_encrypt(text, key):
    rail = [['\n' for i in range(len(text))] for j in range(key)]
    dir_down = False
    row, col = 0, 0

    for i in range(len(text)):
        if row == 0 or row == key - 1:
            dir_down = not dir_down
        rail[row][col] = text[i]
        col += 1
        row += 1 if dir_down else -1

    encrypted_text = []
    for i in range(key):
        for j in range(len(text)):
            if rail[i][j] != '\n':
                encrypted_text.append(rail[i][j])
    return ''.join(encrypted_text)

def rail_fence_decrypt(cipher, key):
    rail = [['\n' for i in range(len(cipher))] for j in range(key)]
    dir_down = None
    row, col = 0, 0

    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        rail[row][col] = '*'
        col += 1
        row += 1 if dir_down else -1

    index = 0
    for i in range(key):
        for j in range(len(cipher)):
            if rail[i][j] == '*' and index < len(cipher):
                rail[i][j] = cipher[index]
                index += 1

    result = []
    row, col = 0, 0
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        if rail[row][col] != '\n':
            result.append(rail[row][col])
            col += 1
        row += 1 if dir_down else -1
    return ''.join(result)

# Encrypt using all ciphers, including Rail Fence
def encrypt_password_with_rail_fence(password, rail_key):
    password = replace_special_characters(password)
    caesar_encrypted = caesar_cipher(password, SHIFT)
    homophonic_encrypted = homophonic_substitution(caesar_encrypted)
    napoleon_encrypted = napoleon_cipher(homophonic_encrypted)
    rail_fence_encrypted = rail_fence_encrypt(napoleon_encrypted, rail_key)
    return rail_fence_encrypted

# Decrypt using all ciphers, including Rail Fence
def decrypt_password_with_rail_fence(encrypted_password, rail_key):
    rail_fence_decrypted = rail_fence_decrypt(encrypted_password, rail_key)
    napoleon_decrypted = napoleon_decipher(rail_fence_decrypted)
    homophonic_decrypted = homophonic_desubstitution(napoleon_decrypted)
    caesar_decrypted = caesar_decipher(homophonic_decrypted, SHIFT)
    decrypted_password = reverse_replace_special_characters(caesar_decrypted)
    return decrypted_password


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python encrypt_message.py <option> <message>")
        sys.exit(1)

    option = sys.argv[1]
    password = sys.argv[2]

    if password:
        if option == 'encrypt':
            encrypted_password = encrypt_password_with_rail_fence(password, 2)
            print(encrypted_password)  # Output the encrypted password
        elif option == 'decrypt':
            try:
                decrypted_password = decrypt_password_with_rail_fence(password, 2)
                print(decrypted_password)  # Output the decrypted password
            except ValueError as e:
                print(f"Error: {e}")
        else:
            print("Invalid option. Please enter 'encrypt' or 'decrypt'.")
    else:
        print("Please enter a password.")
